Kodi yandex-music plugin

based on yandex-music python library
https://github.com/MarshalX/yandex-music-api

install 2 plugins:
script.module.yandex-music.zip from https://github.com/Angel777d/kodi.script.module.yandex-music
and kodi.plugin.yandex-music.zip 