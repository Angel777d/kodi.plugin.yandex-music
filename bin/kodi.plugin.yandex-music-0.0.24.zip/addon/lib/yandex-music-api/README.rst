[Fork] Неофициальная Python библиотека для API Yandex Music
================================================================

Форк https://github.com/MarshalX/yandex-music-api
Даунгрейд библиотеки до Python 2.7
