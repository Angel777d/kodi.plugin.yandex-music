AAC
===

.. automodule:: mutagen.aac

.. autoexception:: mutagen.aac.AACError

.. autoclass:: mutagen.aac.AAC(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.aac.AACInfo()
    :show-inheritance:
    :members:
