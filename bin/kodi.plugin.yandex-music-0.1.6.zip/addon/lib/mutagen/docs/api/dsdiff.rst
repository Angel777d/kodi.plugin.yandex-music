DSDIFF
======

.. automodule:: mutagen.dsdiff

.. autoclass:: mutagen.dsdiff.DSDIFF
    :show-inheritance:
    :members:

.. autoclass:: mutagen.dsdiff.DSDIFFInfo
    :members:
