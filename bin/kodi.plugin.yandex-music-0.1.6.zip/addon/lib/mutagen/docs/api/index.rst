API Reference
=============

.. toctree::

    base
    aac
    ac3
    aiff
    ape
    asf
    dsdiff
    dsf
    flac
    id3
    monkeysaudio
    mp3
    mp4
    musepack
    ogg
    oggflac
    oggopus
    oggspeex
    oggtheora
    oggvorbis
    optimfrog
    smf
    tak
    trueaudio
    vcomment
    wave
    wavpack
