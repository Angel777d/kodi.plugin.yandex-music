Changelog
=========

.. py:currentmodule:: mutagen

.. include:: ../NEWS
