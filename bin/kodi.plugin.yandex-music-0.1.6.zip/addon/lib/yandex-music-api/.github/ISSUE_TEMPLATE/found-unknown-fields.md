---
name: Found unknown fields
about: Создать отчёт об неизвестном поле пришедшим от API
title: Новое неизвестное поле от API
labels: feature
assignees: ''

---

### По просьбе из WARNING'a прикладываю отладочную информацию ниже, которая поможет Вам в разработке:

```
your_copy_paste

```