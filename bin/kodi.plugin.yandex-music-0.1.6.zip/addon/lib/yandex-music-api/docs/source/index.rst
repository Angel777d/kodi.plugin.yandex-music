.. yandex-music-api documentation master file, created by
   sphinx-quickstart on Tue Jun  4 13:45:53 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Документация библиотеки
=======================

.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 2

   readme
   token
   client
   client_async
   examples
   module
   changes
   contributing
   code_of_conduct
   security
   licence
