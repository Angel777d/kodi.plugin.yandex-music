# Модуль

```{eval-rst}
.. include:: yandex_music.rst
```
