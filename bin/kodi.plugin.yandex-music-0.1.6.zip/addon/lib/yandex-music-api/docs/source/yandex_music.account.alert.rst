yandex\_music.account.alert
===========================

.. automodule:: yandex_music.account.alert
   :members:
   :undoc-members:
   :show-inheritance:
