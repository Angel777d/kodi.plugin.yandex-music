yandex\_music.account.alert\_button
===================================

.. automodule:: yandex_music.account.alert_button
   :members:
   :undoc-members:
   :show-inheritance:
