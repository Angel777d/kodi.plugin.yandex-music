yandex\_music.account.permissions
=================================

.. automodule:: yandex_music.account.permissions
   :members:
   :undoc-members:
   :show-inheritance:
