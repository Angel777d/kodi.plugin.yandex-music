yandex\_music.account.price
===========================

.. automodule:: yandex_music.account.price
   :members:
   :undoc-members:
   :show-inheritance:
