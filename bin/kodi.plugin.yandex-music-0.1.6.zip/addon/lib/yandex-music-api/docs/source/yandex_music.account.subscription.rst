yandex\_music.account.subscription
==================================

.. automodule:: yandex_music.account.subscription
   :members:
   :undoc-members:
   :show-inheritance:
