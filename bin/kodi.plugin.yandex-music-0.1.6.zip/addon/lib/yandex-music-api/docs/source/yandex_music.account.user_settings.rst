yandex\_music.account.user\_settings
====================================

.. automodule:: yandex_music.account.user_settings
   :members:
   :undoc-members:
   :show-inheritance:
