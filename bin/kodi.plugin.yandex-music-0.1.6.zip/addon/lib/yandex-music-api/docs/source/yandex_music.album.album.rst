yandex\_music.album.album
=========================

.. automodule:: yandex_music.album.album
   :members:
   :undoc-members:
   :show-inheritance:
