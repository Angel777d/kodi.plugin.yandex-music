yandex\_music.album.deprecation
===============================

.. automodule:: yandex_music.album.deprecation
   :members:
   :undoc-members:
   :show-inheritance:
