yandex\_music.album.label
=========================

.. automodule:: yandex_music.album.label
   :members:
   :undoc-members:
   :show-inheritance:
