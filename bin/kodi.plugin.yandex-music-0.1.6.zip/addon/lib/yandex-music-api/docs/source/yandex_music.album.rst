yandex\_music.album
===================

.. automodule:: yandex_music.album
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.album.album
   yandex_music.album.deprecation
   yandex_music.album.label
   yandex_music.album.track_position
