yandex\_music.artist.artist
===========================

.. automodule:: yandex_music.artist.artist
   :members:
   :undoc-members:
   :show-inheritance:
