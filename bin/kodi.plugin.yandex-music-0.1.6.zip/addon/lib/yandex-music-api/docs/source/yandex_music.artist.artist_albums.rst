yandex\_music.artist.artist\_albums
===================================

.. automodule:: yandex_music.artist.artist_albums
   :members:
   :undoc-members:
   :show-inheritance:
