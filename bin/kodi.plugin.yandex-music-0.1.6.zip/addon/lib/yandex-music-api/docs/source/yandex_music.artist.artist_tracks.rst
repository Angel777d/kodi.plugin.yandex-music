yandex\_music.artist.artist\_tracks
===================================

.. automodule:: yandex_music.artist.artist_tracks
   :members:
   :undoc-members:
   :show-inheritance:
