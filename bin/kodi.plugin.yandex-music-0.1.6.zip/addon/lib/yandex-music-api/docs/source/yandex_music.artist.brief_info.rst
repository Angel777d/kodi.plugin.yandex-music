yandex\_music.artist.brief\_info
================================

.. automodule:: yandex_music.artist.brief_info
   :members:
   :undoc-members:
   :show-inheritance:
