yandex\_music.artist.counts
===========================

.. automodule:: yandex_music.artist.counts
   :members:
   :undoc-members:
   :show-inheritance:
