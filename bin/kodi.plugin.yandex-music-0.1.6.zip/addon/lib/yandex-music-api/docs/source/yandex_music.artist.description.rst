yandex\_music.artist.description
================================

.. automodule:: yandex_music.artist.description
   :members:
   :undoc-members:
   :show-inheritance:
