yandex\_music.artist.link
=========================

.. automodule:: yandex_music.artist.link
   :members:
   :undoc-members:
   :show-inheritance:
