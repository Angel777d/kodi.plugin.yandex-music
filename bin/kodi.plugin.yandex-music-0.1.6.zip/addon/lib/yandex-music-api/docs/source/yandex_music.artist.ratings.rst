yandex\_music.artist.ratings
============================

.. automodule:: yandex_music.artist.ratings
   :members:
   :undoc-members:
   :show-inheritance:
