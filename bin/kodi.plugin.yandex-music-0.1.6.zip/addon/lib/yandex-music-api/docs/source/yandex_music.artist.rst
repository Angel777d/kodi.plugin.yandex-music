yandex\_music.artist
====================

.. automodule:: yandex_music.artist
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.artist.artist
   yandex_music.artist.artist_albums
   yandex_music.artist.artist_tracks
   yandex_music.artist.brief_info
   yandex_music.artist.counts
   yandex_music.artist.description
   yandex_music.artist.link
   yandex_music.artist.ratings
   yandex_music.artist.vinyl
