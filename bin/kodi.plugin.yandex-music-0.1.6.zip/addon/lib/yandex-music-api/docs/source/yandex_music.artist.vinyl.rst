yandex\_music.artist.vinyl
==========================

.. automodule:: yandex_music.artist.vinyl
   :members:
   :undoc-members:
   :show-inheritance:
