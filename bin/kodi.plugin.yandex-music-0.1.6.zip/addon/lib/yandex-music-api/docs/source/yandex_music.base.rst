yandex\_music.base
==================

.. automodule:: yandex_music.base
   :members:
   :undoc-members:
   :show-inheritance:
