yandex\_music.client
====================

.. automodule:: yandex_music.client
   :members:
   :undoc-members:
   :show-inheritance:
