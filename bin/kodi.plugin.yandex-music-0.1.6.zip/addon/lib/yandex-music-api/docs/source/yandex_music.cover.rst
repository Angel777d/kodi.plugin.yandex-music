yandex\_music.cover
===================

.. automodule:: yandex_music.cover
   :members:
   :undoc-members:
   :show-inheritance:
