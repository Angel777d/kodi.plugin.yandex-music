yandex\_music.download\_info
============================

.. automodule:: yandex_music.download_info
   :members:
   :undoc-members:
   :show-inheritance:
