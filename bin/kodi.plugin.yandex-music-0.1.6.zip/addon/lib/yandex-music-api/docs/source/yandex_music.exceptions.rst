yandex\_music.exceptions
========================

.. automodule:: yandex_music.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
