yandex\_music.experiments
=========================

.. automodule:: yandex_music.experiments
   :members:
   :undoc-members:
   :show-inheritance:
