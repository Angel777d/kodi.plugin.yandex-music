yandex\_music.feed.album\_event
===============================

.. automodule:: yandex_music.feed.album_event
   :members:
   :undoc-members:
   :show-inheritance:
