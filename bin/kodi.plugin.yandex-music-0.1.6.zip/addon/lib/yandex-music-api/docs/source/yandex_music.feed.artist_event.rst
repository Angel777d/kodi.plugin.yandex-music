yandex\_music.feed.artist\_event
================================

.. automodule:: yandex_music.feed.artist_event
   :members:
   :undoc-members:
   :show-inheritance:
