yandex\_music.feed.day
======================

.. automodule:: yandex_music.feed.day
   :members:
   :undoc-members:
   :show-inheritance:
