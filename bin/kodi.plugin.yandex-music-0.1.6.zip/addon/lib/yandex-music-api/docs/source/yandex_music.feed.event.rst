yandex\_music.feed.event
========================

.. automodule:: yandex_music.feed.event
   :members:
   :undoc-members:
   :show-inheritance:
