yandex\_music.feed.feed
=======================

.. automodule:: yandex_music.feed.feed
   :members:
   :undoc-members:
   :show-inheritance:
