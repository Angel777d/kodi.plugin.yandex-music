yandex\_music.feed.generated\_playlist
======================================

.. automodule:: yandex_music.feed.generated_playlist
   :members:
   :undoc-members:
   :show-inheritance:
