yandex\_music.feed
==================

.. automodule:: yandex_music.feed
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.feed.album_event
   yandex_music.feed.artist_event
   yandex_music.feed.day
   yandex_music.feed.event
   yandex_music.feed.feed
   yandex_music.feed.generated_playlist
   yandex_music.feed.track_with_ads
