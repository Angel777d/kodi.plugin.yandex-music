yandex\_music.genre.genre
=========================

.. automodule:: yandex_music.genre.genre
   :members:
   :undoc-members:
   :show-inheritance:
