yandex\_music.genre
===================

.. automodule:: yandex_music.genre
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.genre.genre
   yandex_music.genre.images
   yandex_music.genre.title
