yandex\_music.genre.title
=========================

.. automodule:: yandex_music.genre.title
   :members:
   :undoc-members:
   :show-inheritance:
