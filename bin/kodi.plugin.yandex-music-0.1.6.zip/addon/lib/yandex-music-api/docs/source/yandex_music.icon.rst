yandex\_music.icon
==================

.. automodule:: yandex_music.icon
   :members:
   :undoc-members:
   :show-inheritance:
