yandex\_music.invocation\_info
==============================

.. automodule:: yandex_music.invocation_info
   :members:
   :undoc-members:
   :show-inheritance:
