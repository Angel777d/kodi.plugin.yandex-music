yandex\_music.landing.block\_entity
===================================

.. automodule:: yandex_music.landing.block_entity
   :members:
   :undoc-members:
   :show-inheritance:
