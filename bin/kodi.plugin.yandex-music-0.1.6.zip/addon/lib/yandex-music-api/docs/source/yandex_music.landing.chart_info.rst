yandex\_music.landing.chart\_info
=================================

.. automodule:: yandex_music.landing.chart_info
   :members:
   :undoc-members:
   :show-inheritance:
