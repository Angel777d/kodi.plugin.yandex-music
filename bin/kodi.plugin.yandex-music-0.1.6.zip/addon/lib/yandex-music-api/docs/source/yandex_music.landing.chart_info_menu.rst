yandex\_music.landing.chart\_info\_menu
=======================================

.. automodule:: yandex_music.landing.chart_info_menu
   :members:
   :undoc-members:
   :show-inheritance:
