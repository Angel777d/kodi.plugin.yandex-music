yandex\_music.landing.chart\_info\_menu\_item
=============================================

.. automodule:: yandex_music.landing.chart_info_menu_item
   :members:
   :undoc-members:
   :show-inheritance:
