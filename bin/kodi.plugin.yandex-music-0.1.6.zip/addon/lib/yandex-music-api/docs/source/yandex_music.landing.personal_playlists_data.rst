yandex\_music.landing.personal\_playlists\_data
===============================================

.. automodule:: yandex_music.landing.personal_playlists_data
   :members:
   :undoc-members:
   :show-inheritance:
