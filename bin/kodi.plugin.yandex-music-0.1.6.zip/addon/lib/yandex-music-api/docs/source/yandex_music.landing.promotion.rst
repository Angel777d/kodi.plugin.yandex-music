yandex\_music.landing.promotion
===============================

.. automodule:: yandex_music.landing.promotion
   :members:
   :undoc-members:
   :show-inheritance:
