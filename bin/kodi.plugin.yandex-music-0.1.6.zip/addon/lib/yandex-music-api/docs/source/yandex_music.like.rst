yandex\_music.like
==================

.. automodule:: yandex_music.like
   :members:
   :undoc-members:
   :show-inheritance:
