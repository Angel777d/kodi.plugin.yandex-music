yandex\_music.pager
===================

.. automodule:: yandex_music.pager
   :members:
   :undoc-members:
   :show-inheritance:
