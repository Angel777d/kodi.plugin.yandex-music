yandex\_music.permission\_alerts
================================

.. automodule:: yandex_music.permission_alerts
   :members:
   :undoc-members:
   :show-inheritance:
