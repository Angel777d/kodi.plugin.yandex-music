yandex\_music.playlist.custom\_wave
===================================

.. automodule:: yandex_music.playlist.custom_wave
   :members:
   :undoc-members:
   :show-inheritance:
