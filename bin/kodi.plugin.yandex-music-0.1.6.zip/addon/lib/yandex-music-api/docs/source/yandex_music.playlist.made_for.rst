yandex\_music.playlist.made\_for
================================

.. automodule:: yandex_music.playlist.made_for
   :members:
   :undoc-members:
   :show-inheritance:
