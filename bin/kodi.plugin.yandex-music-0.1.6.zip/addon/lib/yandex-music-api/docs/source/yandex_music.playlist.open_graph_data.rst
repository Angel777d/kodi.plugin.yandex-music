yandex\_music.playlist.open\_graph\_data
========================================

.. automodule:: yandex_music.playlist.open_graph_data
   :members:
   :undoc-members:
   :show-inheritance:
