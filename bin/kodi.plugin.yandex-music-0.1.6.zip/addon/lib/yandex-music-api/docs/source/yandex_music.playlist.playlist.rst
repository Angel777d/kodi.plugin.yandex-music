yandex\_music.playlist.playlist
===============================

.. automodule:: yandex_music.playlist.playlist
   :members:
   :undoc-members:
   :show-inheritance:
