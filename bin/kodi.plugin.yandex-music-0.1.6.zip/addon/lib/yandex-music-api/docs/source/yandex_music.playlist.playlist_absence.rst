yandex\_music.playlist.playlist\_absence
========================================

.. automodule:: yandex_music.playlist.playlist_absence
   :members:
   :undoc-members:
   :show-inheritance:
