yandex\_music.playlist.playlist\_recommendation
===============================================

.. automodule:: yandex_music.playlist.playlist_recommendation
   :members:
   :undoc-members:
   :show-inheritance:
