yandex\_music.playlist.tag
==========================

.. automodule:: yandex_music.playlist.tag
   :members:
   :undoc-members:
   :show-inheritance:
