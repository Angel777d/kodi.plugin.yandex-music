yandex\_music.playlist.tag\_result
==================================

.. automodule:: yandex_music.playlist.tag_result
   :members:
   :undoc-members:
   :show-inheritance:
