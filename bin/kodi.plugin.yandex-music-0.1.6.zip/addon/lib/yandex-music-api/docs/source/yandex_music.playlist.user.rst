yandex\_music.playlist.user
===========================

.. automodule:: yandex_music.playlist.user
   :members:
   :undoc-members:
   :show-inheritance:
