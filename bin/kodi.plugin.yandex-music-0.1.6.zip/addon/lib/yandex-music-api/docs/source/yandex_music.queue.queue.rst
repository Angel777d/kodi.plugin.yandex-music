yandex\_music.queue.queue
=========================

.. automodule:: yandex_music.queue.queue
   :members:
   :undoc-members:
   :show-inheritance:
