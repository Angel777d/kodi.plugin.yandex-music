yandex\_music.queue.queue\_item
===============================

.. automodule:: yandex_music.queue.queue_item
   :members:
   :undoc-members:
   :show-inheritance:
