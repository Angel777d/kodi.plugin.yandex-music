yandex\_music.queue
===================

.. automodule:: yandex_music.queue
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.queue.context
   yandex_music.queue.queue
   yandex_music.queue.queue_item
