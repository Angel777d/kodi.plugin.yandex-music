yandex\_music.rotor.ad\_params
==============================

.. automodule:: yandex_music.rotor.ad_params
   :members:
   :undoc-members:
   :show-inheritance:
