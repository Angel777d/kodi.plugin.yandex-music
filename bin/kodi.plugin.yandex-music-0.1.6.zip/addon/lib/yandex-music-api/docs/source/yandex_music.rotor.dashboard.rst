yandex\_music.rotor.dashboard
=============================

.. automodule:: yandex_music.rotor.dashboard
   :members:
   :undoc-members:
   :show-inheritance:
