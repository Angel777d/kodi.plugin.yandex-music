yandex\_music.rotor.discrete\_scale
===================================

.. automodule:: yandex_music.rotor.discrete_scale
   :members:
   :undoc-members:
   :show-inheritance:
