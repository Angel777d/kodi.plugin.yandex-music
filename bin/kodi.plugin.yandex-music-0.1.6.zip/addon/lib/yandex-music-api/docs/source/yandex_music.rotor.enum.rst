yandex\_music.rotor.enum
========================

.. automodule:: yandex_music.rotor.enum
   :members:
   :undoc-members:
   :show-inheritance:
