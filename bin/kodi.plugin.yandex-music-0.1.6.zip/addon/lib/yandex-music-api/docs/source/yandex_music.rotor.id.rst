yandex\_music.rotor.id
======================

.. automodule:: yandex_music.rotor.id
   :members:
   :undoc-members:
   :show-inheritance:
