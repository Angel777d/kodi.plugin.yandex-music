yandex\_music.rotor.restrictions
================================

.. automodule:: yandex_music.rotor.restrictions
   :members:
   :undoc-members:
   :show-inheritance:
