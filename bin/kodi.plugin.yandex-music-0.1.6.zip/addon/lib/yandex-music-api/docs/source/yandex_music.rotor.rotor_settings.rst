yandex\_music.rotor.rotor\_settings
===================================

.. automodule:: yandex_music.rotor.rotor_settings
   :members:
   :undoc-members:
   :show-inheritance:
