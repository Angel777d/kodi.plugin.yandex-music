yandex\_music.rotor.sequence
============================

.. automodule:: yandex_music.rotor.sequence
   :members:
   :undoc-members:
   :show-inheritance:
