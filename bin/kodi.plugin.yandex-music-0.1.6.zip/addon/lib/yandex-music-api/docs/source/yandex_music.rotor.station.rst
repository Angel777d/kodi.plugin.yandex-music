yandex\_music.rotor.station
===========================

.. automodule:: yandex_music.rotor.station
   :members:
   :undoc-members:
   :show-inheritance:
