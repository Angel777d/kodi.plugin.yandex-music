yandex\_music.rotor.value
=========================

.. automodule:: yandex_music.rotor.value
   :members:
   :undoc-members:
   :show-inheritance:
