yandex\_music.search.best
=========================

.. automodule:: yandex_music.search.best
   :members:
   :undoc-members:
   :show-inheritance:
