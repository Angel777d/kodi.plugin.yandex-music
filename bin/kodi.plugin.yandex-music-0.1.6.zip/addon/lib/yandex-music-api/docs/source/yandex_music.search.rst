yandex\_music.search
====================

.. automodule:: yandex_music.search
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.search.best
   yandex_music.search.search
   yandex_music.search.search_result
   yandex_music.search.suggestions
