yandex\_music.search.search
===========================

.. automodule:: yandex_music.search.search
   :members:
   :undoc-members:
   :show-inheritance:
