yandex\_music.search.search\_result
===================================

.. automodule:: yandex_music.search.search_result
   :members:
   :undoc-members:
   :show-inheritance:
