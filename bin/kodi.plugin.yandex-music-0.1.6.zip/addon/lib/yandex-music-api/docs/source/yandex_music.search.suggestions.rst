yandex\_music.search.suggestions
================================

.. automodule:: yandex_music.search.suggestions
   :members:
   :undoc-members:
   :show-inheritance:
