yandex\_music.settings
======================

.. automodule:: yandex_music.settings
   :members:
   :undoc-members:
   :show-inheritance:
