yandex\_music.shot
==================

.. automodule:: yandex_music.shot
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.shot.shot
   yandex_music.shot.shot_data
   yandex_music.shot.shot_event
   yandex_music.shot.shot_type
