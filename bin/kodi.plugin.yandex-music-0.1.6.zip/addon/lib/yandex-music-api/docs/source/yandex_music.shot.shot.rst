yandex\_music.shot.shot
=======================

.. automodule:: yandex_music.shot.shot
   :members:
   :undoc-members:
   :show-inheritance:
