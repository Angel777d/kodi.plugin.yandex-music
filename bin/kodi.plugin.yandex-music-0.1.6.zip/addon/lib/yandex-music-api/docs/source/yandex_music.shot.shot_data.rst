yandex\_music.shot.shot\_data
=============================

.. automodule:: yandex_music.shot.shot_data
   :members:
   :undoc-members:
   :show-inheritance:
