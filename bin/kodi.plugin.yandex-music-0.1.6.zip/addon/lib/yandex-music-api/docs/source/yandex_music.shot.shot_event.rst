yandex\_music.shot.shot\_event
==============================

.. automodule:: yandex_music.shot.shot_event
   :members:
   :undoc-members:
   :show-inheritance:
