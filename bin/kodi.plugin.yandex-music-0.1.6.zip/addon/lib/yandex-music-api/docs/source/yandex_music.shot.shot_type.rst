yandex\_music.shot.shot\_type
=============================

.. automodule:: yandex_music.shot.shot_type
   :members:
   :undoc-members:
   :show-inheritance:
