yandex\_music.supplement.lyrics
===============================

.. automodule:: yandex_music.supplement.lyrics
   :members:
   :undoc-members:
   :show-inheritance:
