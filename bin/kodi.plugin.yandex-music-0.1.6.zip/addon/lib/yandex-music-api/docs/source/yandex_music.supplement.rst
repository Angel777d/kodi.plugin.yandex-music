yandex\_music.supplement
========================

.. automodule:: yandex_music.supplement
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.supplement.lyrics
   yandex_music.supplement.supplement
   yandex_music.supplement.video_supplement
