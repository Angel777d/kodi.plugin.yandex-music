yandex\_music.supplement.supplement
===================================

.. automodule:: yandex_music.supplement.supplement
   :members:
   :undoc-members:
   :show-inheritance:
