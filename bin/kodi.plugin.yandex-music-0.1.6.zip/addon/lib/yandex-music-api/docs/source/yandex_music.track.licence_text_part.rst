yandex\_music.track.licence\_text\_part
=======================================

.. automodule:: yandex_music.track.licence_text_part
   :members:
   :undoc-members:
   :show-inheritance:
