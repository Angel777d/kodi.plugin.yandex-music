yandex\_music.track.lyrics\_info
================================

.. automodule:: yandex_music.track.lyrics_info
   :members:
   :undoc-members:
   :show-inheritance:
