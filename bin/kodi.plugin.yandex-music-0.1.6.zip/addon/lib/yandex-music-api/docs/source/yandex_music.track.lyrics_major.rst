yandex\_music.track.lyrics\_major
=================================

.. automodule:: yandex_music.track.lyrics_major
   :members:
   :undoc-members:
   :show-inheritance:
