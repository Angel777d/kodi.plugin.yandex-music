yandex\_music.track.major
=========================

.. automodule:: yandex_music.track.major
   :members:
   :undoc-members:
   :show-inheritance:
