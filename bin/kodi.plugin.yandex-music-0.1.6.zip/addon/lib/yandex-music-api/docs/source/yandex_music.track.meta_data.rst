yandex\_music.track.meta\_data
==============================

.. automodule:: yandex_music.track.meta_data
   :members:
   :undoc-members:
   :show-inheritance:
