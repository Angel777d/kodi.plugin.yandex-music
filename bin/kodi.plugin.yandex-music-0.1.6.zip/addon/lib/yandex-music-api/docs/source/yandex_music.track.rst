yandex\_music.track
===================

.. automodule:: yandex_music.track
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   yandex_music.track.licence_text_part
   yandex_music.track.lyrics_info
   yandex_music.track.lyrics_major
   yandex_music.track.major
   yandex_music.track.meta_data
   yandex_music.track.normalization
   yandex_music.track.poetry_lover_match
   yandex_music.track.r128
   yandex_music.track.track
   yandex_music.track.track_lyrics
   yandex_music.track.tracks_similar
