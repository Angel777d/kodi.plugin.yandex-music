yandex\_music.track.track\_lyrics
=================================

.. automodule:: yandex_music.track.track_lyrics
   :members:
   :undoc-members:
   :show-inheritance:
