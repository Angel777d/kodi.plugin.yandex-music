yandex\_music.track\_short
==========================

.. automodule:: yandex_music.track_short
   :members:
   :undoc-members:
   :show-inheritance:
