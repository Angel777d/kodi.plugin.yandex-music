yandex\_music.utils.request\_async
==================================

.. automodule:: yandex_music.utils.request_async
   :members:
   :undoc-members:
   :show-inheritance:
